import React from 'react';
import Guidelines from './Guidelines';

const SubmissionGuidelines = () => {
  return <Guidelines />;
};

export default SubmissionGuidelines; 