import React from 'react';
import Committee from '../components/Committee';

const CommitteePage = () => {
  return (
    <>
      <Committee />
    </>
  );
};

export default CommitteePage;