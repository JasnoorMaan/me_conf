import React from 'react';
import AdvisoryComm from '../components/AdvisoryComm';

const Advisory = () => {
  return <AdvisoryComm />;
};

export default Advisory;